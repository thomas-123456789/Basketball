import streamlit as st
if st.button("Chatbot"):
    st.switch_page("page1")



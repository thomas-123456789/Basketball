from st_pages.home import run as home
from st_pages.model_management import run as model_management
from st_pages.ai_chatbot import run as ai_chatbot
from st_pages.rag_chat import run as rag_chat
